
# EDA and Model Notebook (suggested)

This notebook should include:
- Load `data/processed/cleaned_transactions.csv`
- Visualize monthly totals and category breakdowns
- Plot seasonality and rolling averages
- Train baseline models and compare metrics
